<script lang="ts">
import Titulo from './components/Titulo.vue'
import ConteudoPrincipal from './components/ConteudoPrincipal.vue'

export default{
  components: { Titulo, ConteudoPrincipal }
}
</script>

<template>
  <Titulo />
  <ConteudoPrincipal/>
</template>