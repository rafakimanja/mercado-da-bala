<script lang="ts">
import type IMovimentacoes from '@/interface/IMovimentacoes';
import CardsTransferencia from './CardsTransferencia.vue';

export default{
    components: { CardsTransferencia },
    data(){
        return{
            transferencias: [] as IMovimentacoes[]
        };
    }
};

</script>

<template>
    <div class="filtros">
        <p>Filtrar por:</p>
        <ul>
            <li><input type="checkbox">transferência</li>
            <li><input type="checkbox">entrada</li>
            <li><input type="checkbox">saída</li>
            <li><input type="checkbox">banco</li>
        </ul>
    </div>

    <div class="cards-transferencias" v-for="transferencia in transferencias" :key="transferencia.nome">
        <CardsTransferencia :transferencia="transferencia"/>
    </div>
</template>


<style scoped>

.filtros{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    margin-top: 4rem;
}

.filtros p{
    font-weight: bold;
}

ul{
    display: flex;
    flex-direction: row;
    list-style: none;
}

li{
    display: flex;
    align-items: center;
    margin-right: 10px;
}

.cards-transferencias{
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    margin-bottom: 5rem;
    margin-top: 5rem;
}

</style>