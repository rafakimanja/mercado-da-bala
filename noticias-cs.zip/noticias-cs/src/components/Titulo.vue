<template>

    <header>
        <h1>Mercado da Bala</h1>
        <p>Um projeto Full-Stack sobre as transferências no cenário de <span>Counter Strike 2</span> </p>
    </header>

</template>


<style scoped>

header{
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    margin-top: 20px;
}

h1{
    font-weight: 700;
    font-size: 50px;
}

p{
    margin-top: 0;
    font-size: large;
    font-weight: bold;
}

span{
    color: #E38617;
    font-style: italic;
}
</style>