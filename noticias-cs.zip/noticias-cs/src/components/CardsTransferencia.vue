<script lang="ts">
import { obtemTransferencias } from '@/http';
import type IMovimentacoes from '@/interface/IMovimentacoes';
export default{
    data(){
        return{
            transferencias: [] as IMovimentacoes[]
        }
    },
    async created(){
        this.transferencias = await obtemTransferencias()
    }
}

</script>

<template>
    <div>
    <div class="card-transferencia" id="transferencia">
      <h3>Transferência</h3>
      <p><span>BlameF</span> se transferiu da <span>Astralis</span> para <span>Fnatic</span></p>
    </div>
    <div class="card-transferencia" id="entrada">
      <h3>Entrada</h3>
      <p><span>Pluto</span> entrou na <span>BOSS</span></p>
    </div>
    <div class="card-transferencia" id="saida">
      <h3>Saída</h3>
      <p><span>dennyslaw</span> saiu da <span>500</span></p>
    </div>
    <div class="card-transferencia" id="banco">
      <h3>Banco</h3>
      <p><span>ponter</span> foi ao banco da <span>ODDIK</span></p>
    </div>
  </div>
</template>


<style scoped>

.card-transferencia{
    height: 120px;
    width: 400px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
    margin-bottom: 2rem;
}

.card-transferencia span{
    font-weight: bold;
}

h3{
    margin: 0;
}

#transferencia{
    background-color: rgba(0, 128, 0, 0.37);
}

#entrada{
    background-color: rgba(28, 0, 190, 0.411);
}

#saida{
    background-color: rgba(190, 0, 0, 0.486);
}

#banco{
    background-color: rgba(190, 161, 0, 0.452);
}
</style>