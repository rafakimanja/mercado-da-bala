export default interface IMovimentacoes {
    nome: String
    origem: String
    destino: String
    movimentacao: String
}