import type IMovimentacoes from "@/interface/IMovimentacoes";

export async function obtemTransferencias() {
    const resposta = await fetch('')

    const transferencias: IMovimentacoes[] = await resposta.json()

    return transferencias
}